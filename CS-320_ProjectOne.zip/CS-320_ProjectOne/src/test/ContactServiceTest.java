package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import contactService.Contact;
import contactService.ContactService;


public class ContactServiceTest {  
	
	@Test
    public void testAdd(){
    ContactService cs = new ContactService();
    Contact t1 = new Contact("T1", "John", "Doe", "12345", "215 address rd 12345");
    assertEquals(true, cs.addContact(t1));
}

@Test
public void testDelete(){

    ContactService cs = new ContactService();

    Contact t1 = new Contact("T1", "John", "Doe", "123456", "215 address rd 123456");
    Contact t2 = new Contact("T2", "Jane", "Doe", "1234567", "215 address rd 1234567");
    Contact t3 = new Contact("T3", "Paul", "Doe", "12345678", "215 address rd 12345678");

    cs.addContact(t1);
    cs.addContact(t2);
    cs.addContact(t3);

    assertEquals(false, cs.deleteContact("T1"));
    assertEquals(false, cs.deleteContact("T2"));
    assertEquals(false, cs.deleteContact("T3"));
}

@Test
public void testUpdate(){
    ContactService cs = new ContactService();

    Contact t1 = new Contact("T1", "John", "Doe", "123456", "215 address rd 123456");
    Contact t2 = new Contact("T2", "Jane", "Doe", "1234567", "215 address rd 1234567");
    Contact t3 = new Contact("T3", "Paul", "Doe", "12345678", "215 address rd 12345678");

    cs.addContact(t1);
    cs.addContact(t2);
    cs.addContact(t3);

    assertEquals(true, cs.updateContact("T2", "Jane", "Doe", "1234567", "215 address rd 1234567"));
    assertEquals(true, cs.updateContact("T3", "Paul", "Doe", "12345678", "215 address rd 12345678"));
}

}