package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import contactService.Contact;
import contactService.ContactService;

class ContactTest {

    Contact contact = new Contact("1", "firstName", "lastName", "123456789", "3215 address rd 123456789");

    @Test
    void getContactID() {
        assertEquals("1", contact.getContactID());
    }
    @Test
    void getFirstName() {
        assertEquals("firstName", contact.getFirstName());
    }
    @Test
    void getLastName() {
        assertEquals("lastName", contact.getLastName());
    }
    @Test
    void getNumber() {
        assertEquals("123456789", contact.getNumber());
    }
    @Test
    void getAddress() {
        assertEquals("3215 address rd 123456789", contact.getAddress());
    }
    @Test
    void testToString() {
        assertEquals("Contact [contactID = 1, firstName = firstName, lastName = lastName, Number = 123456789, address = 3215 address rd 123456789]", contact.toString());
    }
}