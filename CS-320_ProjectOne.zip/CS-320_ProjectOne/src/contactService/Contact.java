package contactService;

public class Contact {
	
	//Variables
	private String contactID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	
	public Contact(String contactID, String firstName, String lastName, String number, String address) {
		
		//if statements for invalid entries
		
		if(contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Invalid Contact ID - null or length greater than 10");
		}
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name - null or length greater than 10");
		}
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name - null or length greater than 10");
		}
		if(number == null || number.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number - null or length greater than 10");
		}
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address - null or length greater than 10");
		}
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.address = address;
	}
	
	// Getters
	public String getContactID() {
		return this.contactID;
	}
	public String getFirstName() {
		return this.firstName;
	}
	public String getLastName() {
		return this.lastName;
	}
	public String getNumber() {
		return this.number;
	}
	public String getAddress() {
		return this.address;
	}
	
	// Setters
	public void setContactID(String contactId) {
		this.contactID = contactID;
	}
	public void setFirstName(String fName) {
		this.firstName = firstName;
	}
	public void setLastName(String lName) {
		this.lastName = lastName;
	}
	public void setNumber(String num) {
		this.number = number;
	}
	public void setAddress(String addr) {
		this.address = address;
	}
	
	@Override
    public String toString() {
        return "Contact [" +
                "contactID = " + contactID  +
                ", firstName = " + firstName  +
                ", lastName = " + lastName  +
                ", Number = " + number +
                ", address = " + address  +
                ']';
	}	
}
