package test;

import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import appointmentService.AppointmentService;
import appointmentService.Appointment;

class AppointmentServiceTest {

    @Test
    public void testAdd(){
        AppointmentService cs = new AppointmentService();
        Appointment t1 = new Appointment("T1", "date" , "Description: Test description to hold 50 characters");
        assertEquals(true, cs.addAppointment(t1));
    }

    @Test
    public void testDelete(){

    	AppointmentService cs = new AppointmentService();

    	Appointment t1 = new Appointment("T1", "date" , "Description: Test description to hold 50 characters");
    	Appointment t2 = new Appointment("T2", "date" , "Description: Test description to hold 50 characters");
    	Appointment t3 = new Appointment("T3", "date" , "Description: Test description to hold 50 characters");

        cs.addAppointment(t1);
        cs.addAppointment(t2);
        cs.addAppointment(t3);

        assertEquals(false, cs.deleteAppointment("T1"));
        assertEquals(false, cs.deleteAppointment("T2"));
        assertEquals(false, cs.deleteAppointment("T3"));
    }

    @Test
    public void testUpdate(){
    	AppointmentService cs = new AppointmentService();

        Appointment t1 = new Appointment("T1", "date" , "Description: Test description to hold 50 characters");
        Appointment t2 = new Appointment("T2", "date" , "Description: Test description to hold 50 characters");
        Appointment t3 = new Appointment("T3", "date" , "Description: Test description to hold 50 characters");

        cs.addAppointment(t1);
        cs.addAppointment(t2);
        cs.addAppointment(t3);


    }
}
	