package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.*;
import org.junit.jupiter.api.Test;

import appointmentService.Appointment;
import appointmentService.AppointmentService;

class AppointmentTest {

	Appointment appointment = new Appointment("T1", "date" , "Description: Test description to hold 50 characters");

    @Test
    void getAppointmentID() {
        assertEquals("1", appointment.getID());
    }
    @Test
    void getFirstName() {
        assertEquals("firstName", appointment.getDate());
    }
    @Test
    void getLastName() {
        assertEquals("lastName", appointment.getDescription());
    }
    @Test
    void testToString() {
        assertEquals("Appointment [appointmentID = 1, date = date, Description = Test description to hold 50 characters]", appointment.toString());
    }
}