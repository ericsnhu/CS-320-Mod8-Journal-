package taskService;

public class Task {
	
	private String taskID;
	private String name;
	private String description;
	
	public void Contact(String taskID, String name, String description) {
		
		//if statements for invalid entries
		
		if(taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid Task ID - null or length greater than 10");
		}
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid  Name - null or length greater than 10");
		}
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid  Description - null or length greater than 50");
		}
	
		this.taskID = taskID;
		this.name = name;
		this.description = description;
	}
	
	// Getters
	public String gettaskID() {
		return this.taskID;
	}
	public String getname() {
			return this.name;
	}
	public String getdescription() {
		return this.description;
	}
	
	// Setters
	public void setContactID(String taskID) {
		this.taskID = taskID;
	}
	public void setFirstName(String name) {
		this.name = name;
	}
	public void setLastName(String description) {
		this.description = description;
	}
	
	@Override
    public String toString() {
        return "Task [" +
                "taskID = " + taskID  +
                ", name = " + name  +
                ", description = " + description  +
                ']';
	}

	public void setTaskID(String taskID2) {
		// TODO Auto-generated method stub
		
	}

	public void setName(String name2) {
		// TODO Auto-generated method stub
		
	}

	public void setDescription(String description2) {
		// TODO Auto-generated method stub
		
	}
}

