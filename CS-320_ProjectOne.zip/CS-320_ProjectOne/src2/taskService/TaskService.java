package taskService;

import java.util.ArrayList;


public class TaskService {
	
	private ArrayList<Task> listofTasks;

    public TaskService() {
    	listofTasks = new ArrayList<>();
    }

    public boolean addTask(Task a) {
        boolean TaskExist = false;

        for(Task l:listofTasks) {
            if(l.equals(a)) {
            	TaskExist = true;
            }
        }
        if(!TaskExist) {
        	listofTasks.add(a);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean deleteTask(String taskID) {

        for(Task l:listofTasks) {
            if(l.gettaskID().equals(taskID)) {
            	listofTasks.remove(l);
                return true;
            }
        }
        return false;

    }

    public boolean updateTask(String taskID, String name, String description) {
    	for(Task l:listofTasks) {
            if(l.gettaskID().equals(taskID)) {
                if(!taskID.equals("") && (taskID.length() > 10)) {
                    l.setTaskID(taskID);
                }
                if(!name.equals("") && (name.length() > 20)) {
                    l.setName(name);
                }
                if(!description.equals("") && (description.length() > 50)) {
                    l.setDescription(description);
                }
                return true;
            }
        }
        return false;
    }
}

