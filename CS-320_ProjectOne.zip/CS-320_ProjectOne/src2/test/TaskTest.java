package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import taskService.Task;

class TaskTest {

	Task task = new Task();

    @Test
    void getTaskID() {
        assertEquals("1", task.gettaskID());
    }
    @Test
    void getName() {
        assertEquals("name", task.getname());
    }
    @Test
    void getDescription() {
        assertEquals("description", task.getdescription());
    }
    @Test
    void testToString() {
        assertEquals("Task [taskID = 1, name = name, description = description]", task.toString());
    }
}