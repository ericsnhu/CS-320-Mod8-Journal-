package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskService.Task;
import taskService.TaskService;

class TaskServiceTest {

    @Test
    public void testAdd(){
        TaskService ts = new TaskService();
        Task t1 = new Task();
        assertEquals(true, ts.addTask(t1));
    }

    @Test
    public void testDelete(){

    	TaskService ts = new TaskService();

    	Task t1 = new Task();
    	Task t2 = new Task();
    	Task t3 = new Task();

        ts.addTask(t1);
        ts.addTask(t2);
        ts.addTask(t3);

        assertEquals(false, ts.deleteTask("T1"));
        assertEquals(false, ts.deleteTask("T2"));
        assertEquals(false, ts.deleteTask("T3"));
    }

    @Test
    public void testUpdate(){
    	TaskService ts = new TaskService();

        Task t1 = new Task();
        Task t2 = new Task();
        Task t3 = new Task();

        ts.addTask(t1);
        ts.addTask(t2);
        ts.addTask(t3);

        assertEquals(true, ts.updateTask("T2", "Jane", "Doe"));
        assertEquals(true, ts.updateTask("T3", "Paul", "Doe"));
    }
}